// variabel jumlahKambing menjadi variabel instance


public class IF0210117056Latihan5KambingGlobal {
//method untuk menampilkan jumlah kambing
    int jumlahKambing = 88;
    public void getJumlahKambing() {
        System.out.println("Jumlah Kambing: " + jumlahKambing);
    }
    public void tambahKambing() {
        jumlahKambing = jumlahKambing + 5; 
        System.out.println("jumlahKambing setelah ditambah :" + jumlahKambing);
    }
        
    }
    
